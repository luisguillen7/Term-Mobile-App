package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Course;
import com.example.termapp.Entity.Status;
import com.example.termapp.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class UpdateCourse extends AppCompatActivity {

    /** GUI Fields.*/
    private EditText courseName;
    private Spinner selectedStatus;
    private EditText courseInstructor;
    private EditText coursePhoneNumber;
    private EditText courseEmail;
    private EditText courseStartDate;
    private EditText courseEndDate;
    private EditText courseNotes;

    /**String that stores the selected status.*/
    private Status courseStatus;

    /** DatePicker */
    DatePickerDialog.OnDateSetListener startDate;
    DatePickerDialog.OnDateSetListener endDate;

    /** Calendar Object */
    final Calendar myCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_course);

        Repository repository = new Repository(getApplication()); // Creates repository instance

        /** Identifying GUI controls.*/
         courseName = (EditText) findViewById(R.id.courseNameEditText);
         courseInstructor = (EditText) findViewById(R.id.courseInstructorEditText);
         coursePhoneNumber = (EditText) findViewById(R.id.courseInstructorPhoneNumberEditText);
         courseEmail = (EditText) findViewById(R.id.courseInstructorEmailEditText);
         courseStartDate = (EditText) findViewById(R.id.courseStartDateEditText);
         courseEndDate = (EditText) findViewById(R.id.courseEndDateEditText);
         courseNotes = (EditText) findViewById(R.id.updateCourseNotesEditText);

         /** Status Spinner Code.*/
         selectedStatus = (Spinner) findViewById(R.id.selectCourseStatusSpinner);
        ArrayAdapter<Status> statusAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, repository.statusList);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        selectedStatus.setAdapter(statusAdapter);

        /** Pre-populate spinner with data from previous activity.*/
        String statusOfCourse = getIntent().getStringExtra("Status");

        for(Status s : repository.statusList){
            if(s.getStatusName().equals(statusOfCourse)){
                selectedStatus.setSelection(s.getStatusID());
            }
        }

        selectedStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                /** Stores the item selected from the spinner.*/
                //courseStatus = repository.statusList.get(position);
                courseStatus = (Status) selectedStatus.getSelectedItem();

                /** Displays message when a new term is added.*/


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /** Set values for the text views.*/
        courseName.setText(getIntent().getStringExtra("Course Name"));
        courseStartDate.setText(getIntent().getStringExtra("Start Date"));
        courseEndDate.setText(getIntent().getStringExtra("End Date"));
        courseInstructor.setText(getIntent().getStringExtra("Instructor Name"));
        coursePhoneNumber.setText(getIntent().getStringExtra("Phone Number"));
        courseEmail.setText(getIntent().getStringExtra("Email"));
        courseNotes.setText(getIntent().getStringExtra("Notes"));

        /** Format Date */
        String dateFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);

        /** Enable EditText to pick a date .*/
        courseStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = courseStartDate.getText().toString();

                try {
                    myCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                new DatePickerDialog(UpdateCourse.this, startDate, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        courseEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = courseEndDate.getText().toString();

                try{
                    myCalendar.setTime(sdf.parse(info));
                } catch (ParseException e){
                    e.printStackTrace();
                }

                new DatePickerDialog(UpdateCourse.this, endDate, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartDateEditText();
            }
        };

        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateEndDateEditText();
            }
        };
    } // onCreate

    /**Methods that update the start and end date fields.*/
    private void updateStartDateEditText(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat df = new SimpleDateFormat(myFormat, Locale.US);

        courseStartDate.setText(df.format(myCalendar.getTime()));
    }

    private void updateEndDateEditText(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat df = new SimpleDateFormat(myFormat, Locale.US);

        courseEndDate.setText(df.format(myCalendar.getTime()));
    }

    /**
     * Method that updates a course.
     * @param view
     */
    public void onClickSaveCourse(View view) {

        /** Fields to update.*/
        String updateCourseName = courseName.getText().toString();
        String updateCourseStatus = courseStatus.getStatusName();
        String updateCourseInstructor = courseInstructor.getText().toString();
        String updateCoursePhoneNumber = coursePhoneNumber.getText().toString();
        String updateCourseEmail = courseEmail.getText().toString();
        String updateCourseStartDate = courseStartDate.getText().toString();
        String updateCourseEndDate = courseEndDate.getText().toString();
        String updateCourseNotes = courseNotes.getText().toString();

        /** Get term and status.*/
        String term = getIntent().getStringExtra("Term");
        int termID = getIntent().getIntExtra("Term ID", 0);

        /** Update a course by course ID.*/
        int courseID = getIntent().getIntExtra("Course ID", 0);

        /** Creates repository instance to access DAO methods.*/
        Repository repository = new Repository(getApplication());

        /** Formats Dates.*/
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        Date start = null;
        Date end = null;
        try{
            start = sdf.parse(updateCourseStartDate);
            end = sdf.parse(updateCourseEndDate);
        } catch(ParseException e){
            e.printStackTrace();
        }

        /** Create new course object.*/
        Course updatedCourse = new Course(courseID, termID, term, updateCourseName, start, end, updateCourseStatus, updateCourseInstructor, updateCoursePhoneNumber, updateCourseEmail, updateCourseNotes);
        repository.update(updatedCourse);

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(UpdateCourse.this, MainActivity.class);
        /** Starts next screen.*/
        startActivity(intent);

        /** Displays message when a new term is added.*/
        Toast.makeText(UpdateCourse.this, "Course Updated!", Toast.LENGTH_SHORT).show();
    }
}