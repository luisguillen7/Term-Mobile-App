package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.TypeConverters;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.termapp.Database.DateConverter;
import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Term;
import com.example.termapp.R;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Date;

@TypeConverters(DateConverter.class)
public class TermDetails extends AppCompatActivity {
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_details);

        /** Identifying GUI controls.*/
        TextView termNameTxt = (TextView) findViewById(R.id.termNameTextView);
        TextView startDateTxt = (TextView) findViewById(R.id.termStartDateTextView);
        TextView endDateTxt = (TextView) findViewById(R.id.termEndDateTextView);

        /** Set values for the text views.*/
        termNameTxt.setText(getIntent().getStringExtra("Term Name"));
        startDateTxt.setText(getIntent().getStringExtra("Term Start Date"));
        endDateTxt.setText(getIntent().getStringExtra("Term End Date"));
    }

    /**
     * Method that sends user to the update term screen.
     * @param view
     */
    public void onClickUpdateTerm(View view) {

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(TermDetails.this, UpdateTerm.class);

        /** Date formatter*/
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        /** Key pair values that help tie data when switching screens.*/
        intent.putExtra("Term ID", getIntent().getIntExtra("Term ID", 0));
        intent.putExtra("Term Name", getIntent().getStringExtra("Term Name"));
        intent.putExtra("Term Start Date", getIntent().getStringExtra("Term Start Date"));
        intent.putExtra("Term End Date", getIntent().getStringExtra("Term End Date"));

        startActivity(intent);
    }

    /**
     * Method that deletes a term.
     * @param view
     */
    public void onClickDeleteTerm(View view) {

        /** Creates repository instance to access DAO methods.*/
        Repository repository = new Repository(getApplication());
        
        /** Term Object.*/
        Term deleteTerm = null;

        /** Get term ID.*/
        int termID = getIntent().getIntExtra("Term ID", 0);

        /** For loop that sets the term to be deleted.*/
        for(Term t : repository.getmAllTerms()){
            if(t.getTermID() == termID){
                
                /** Assign a value to the term to be deleted.*/
                deleteTerm = t;
            }
        }

        /** Number of courses.*/
        int numberOfCourses = 0;
        for(com.example.termapp.Entity.Course c :  repository.getmAllCourses()){
            if(c.getTermID() == termID) ++numberOfCourses;
        }

        /** Checks if the term has course.*/
        if(numberOfCourses == 0){
            repository.delete(deleteTerm);

            /** Create intent to go to the next screen.*/
            Intent intent = new Intent(TermDetails.this, MainActivity.class);
            /** Starts next screen.*/
            startActivity(intent);

            /** Displays message when a new term is added.*/
            Toast.makeText(TermDetails.this, "Term Deleted!", Toast.LENGTH_SHORT).show();
        } else {

            /** Displays message when a new term is added.*/
            Toast.makeText(TermDetails.this, "Term has courses and cannot be deleted.", Toast.LENGTH_SHORT).show();
        }

    }
}