package com.example.termapp.Database;


import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverter;
import androidx.room.TypeConverters;

import com.example.termapp.DAO.AssessmentDAO;
import com.example.termapp.DAO.CourseDAO;
import com.example.termapp.DAO.TermDAO;
import com.example.termapp.Entity.Assessment;
import com.example.termapp.Entity.Course;
import com.example.termapp.Entity.Term;

/** Creates database for the term app.*/

@Database(entities = {Term.class, Course.class, Assessment.class}, version = 2, exportSchema = false)
@TypeConverters(DateConverter.class)

public abstract class TermDatabaseBuilder extends RoomDatabase {
    public abstract TermDAO termDAO();
    public abstract CourseDAO courseDAO();
    public abstract AssessmentDAO assessmentDAO();

    private static volatile TermDatabaseBuilder INSTANCE;

    static TermDatabaseBuilder getDatabase(final Context context){

        if(INSTANCE == null ) {
            synchronized (TermDatabaseBuilder.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), TermDatabaseBuilder.class, "termDatabase.db")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }


}
