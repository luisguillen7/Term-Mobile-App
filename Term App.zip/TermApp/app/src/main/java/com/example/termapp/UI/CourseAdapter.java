package com.example.termapp.UI;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Course;
import com.example.termapp.Entity.Status;
import com.example.termapp.Entity.Term;
import com.example.termapp.R;

import java.text.SimpleDateFormat;
import java.util.List;


public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.CourseViewHolder> {
    class CourseViewHolder extends RecyclerView.ViewHolder{
        private final TextView courseItem;
        private CourseViewHolder(View itemView){
            super(itemView);
            courseItem = itemView.findViewById(R.id.courseNameTextView);

            itemView.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view) {
                    /** Date formatter*/
                    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

                    int position = getAdapterPosition();
                    final Course current = mCourses.get(position);

                    Intent intent = new Intent(context, CourseDetails.class);
                    intent.putExtra("Term", current.getTerm());
                    intent.putExtra("Term ID", current.getTermID());
                    intent.putExtra("Course ID", current.getCourseID());
                    intent.putExtra("Course Name", current.getCourseName());
                    intent.putExtra("Status", current.getStatus());
                    intent.putExtra("Start Date", sdf.format(current.getStartDate()));
                    intent.putExtra("End Date", sdf.format(current.getEndDate()));
                    intent.putExtra("Instructor Name", current.getInstructorName());
                    intent.putExtra("Phone Number", current.getPhoneNumber());
                    intent.putExtra("Email", current.getEmail());
                    intent.putExtra("Notes", current.getNotes());
                    context.startActivity(intent);
                }
            });
        }
    }

    private List<Course> mCourses;
    private final Context context;
    private final LayoutInflater mInflator;

    public CourseAdapter(Context context){
        mInflator = LayoutInflater.from(context);
        this.context = context;
    }

    @NonNull
    @Override
    public CourseAdapter.CourseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflator.inflate(R.layout.course_list_item,parent, false);
        return new CourseViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseAdapter.CourseViewHolder holder, int position) {

        if(mCourses != null){
            Course current = mCourses.get(position);
            String name = current.getCourseName();
            holder.courseItem.setText(name);
        }
        else{
            holder.courseItem.setText("No courses available.");
        }
    }

    public void setCourses(List<Course> courses){
        mCourses = courses;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(mCourses != null){
            return mCourses.size();
        }
         else return 0;
    }
}
