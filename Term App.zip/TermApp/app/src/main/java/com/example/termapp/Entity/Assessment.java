package com.example.termapp.Entity;


import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.time.LocalDate;
import java.util.Date;

@Entity(tableName = "assessments")
public class Assessment {

    /** Assessment fields. */
    @PrimaryKey(autoGenerate = true)
    private int assessmentID;

    private int courseID;
    private  String assessmentCourse;
    private String assessmentType;
    private String assessmentTitle;
    private Date starDate;
    private Date endDate;


    /** Assessment Constructor. */
    public Assessment(int assessmentID, int courseID, String assessmentCourse, String assessmentType, String assessmentTitle, Date starDate, Date endDate) {
        this.courseID = courseID;
        this.assessmentID = assessmentID;
        this.assessmentCourse = assessmentCourse;
        this.assessmentType = assessmentType;
        this.assessmentTitle = assessmentTitle;
        this.starDate = starDate;
        this.endDate = endDate;
    }

    /** toString method displays only course name in the spinner.*/
    public String toString() {
        return this.assessmentTitle;
    }


    /** Assessment Getters and Setters.*/

    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }


    public int getAssessmentID() {
        return assessmentID;
    }

    public void setAssessmentID(int assessmentID) {
        this.assessmentID = assessmentID;
    }

    public String getAssessmentCourse() {
        return assessmentCourse;
    }

    public void setAssessmentCourse(String assessmentCourse) {
        this.assessmentCourse = assessmentCourse;
    }

    public String getAssessmentType() {
        return assessmentType;
    }

    public void setAssessmentType(String assessmentType) {
        this.assessmentType = assessmentType;
    }

    public String getAssessmentTitle() {
        return assessmentTitle;
    }

    public void setAssessmentTitle(String assessmentTitle) {
        this.assessmentTitle = assessmentTitle;
    }

    public Date getStarDate() {
        return starDate;
    }

    public void setStarDate(Date starDate) {
        this.starDate = starDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
}
