package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Assessment;
import com.example.termapp.Entity.Course;
import com.example.termapp.R;

import java.util.ArrayList;
import java.util.List;

public class AssessmentList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_list);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        RecyclerView recyclerView = findViewById(R.id.assessmentListRecyclerView);
        Repository repository = new Repository(getApplication());
        List<Assessment> assessments = repository.getmAllAssessments();
        final AssessmentAdapter adapter = new AssessmentAdapter(this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        /**Get term ID.*/
        int courseID = getIntent().getIntExtra("Assessment Course ID", 0);

        /** Filter courses.*/
        ArrayList<Assessment> filteredAssessments = new ArrayList<>();
        for(Assessment a : assessments){
            if(a.getCourseID() == courseID){
                filteredAssessments.add(a);
            }
        }

        /** Sends a list of filtered courses.*/
        adapter.setAssessments(filteredAssessments);

    }
}