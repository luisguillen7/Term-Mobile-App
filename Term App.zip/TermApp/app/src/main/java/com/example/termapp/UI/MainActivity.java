package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.termapp.R;

public class MainActivity extends AppCompatActivity {

    public static int numAlert;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }


    /**
     * This is the View for the Term button.
     * Takes the user to the Term List screen.
     * @param view Not used.
     */
    public void openTerm(View view) {

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(MainActivity.this, TermList.class);
        startActivity(intent);
    }

    /**
     * This is the View for the Courses button.
     * Sends the user to the Courses List screen.
     * @param view Not used.
     */
    public void openCourses(View view) {

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(MainActivity.this, Course.class);
        startActivity(intent);
    }

    /**
     * This is the View for the Assessments buttons.
     * Sends the user to the Assessments button.
     * @param view Not used.
     */
    public void openAssessments(View view) {

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(MainActivity.this, Assessments.class);
        startActivity(intent);

    }
}