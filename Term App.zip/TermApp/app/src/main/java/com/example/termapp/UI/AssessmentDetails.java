package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Assessment;
import com.example.termapp.Entity.Course;
import com.example.termapp.R;

import org.w3c.dom.Text;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AssessmentDetails extends AppCompatActivity {

    /** Declare GUI fields to use them.*/
    TextView courseName;
    TextView assessmentType;
    TextView assessmentTitle;
    TextView startDateTxt;
    TextView endDateTxt;

    String myFormat = "MM/dd/yy";
    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_details);

        /** Displays the action bar.*/
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        /** Identifying GUI controls.*/
         courseName = (TextView) findViewById(R.id.courseNameTextView);
         assessmentType = (TextView) findViewById(R.id.assessmentTypeTextView);
         assessmentTitle = (TextView) findViewById(R.id.assessmentNameTextView);
         startDateTxt = (TextView) findViewById(R.id.startDateTextView);
         endDateTxt = (TextView) findViewById(R.id.endDateTextView);

        /** Set values for the text views.*/
        courseName.setText(getIntent().getStringExtra("Assessment Course Name"));
        assessmentType.setText(getIntent().getStringExtra("Assessment Type"));
        assessmentTitle.setText(getIntent().getStringExtra("Assessment Name"));
        startDateTxt.setText(getIntent().getStringExtra("Assessment Start Date"));
        endDateTxt.setText(getIntent().getStringExtra("Assessment End Date"));

    }

    /** Action Bar Code.*/
    public boolean onCreateOptionsMenu(Menu menu){

        /** Inflate the menu, This adds items to the action bar if it is present.*/
        getMenuInflater().inflate(R.menu.assessment_menu, menu);
        return true;
    }

    /** Selecting an item from the menu.*/
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case android.R.id.home:this.finish();
                return true;
            case R.id.startNotify:
                String startDateFromScreen = startDateTxt.getText().toString();

                /**Course Details.*/
                String startAssessment = assessmentTitle.getText().toString();

                Date startDate = null;

                try{
                    startDate = sdf.parse(startDateFromScreen);
                }catch (ParseException e){
                    e.printStackTrace();
                }
                Long triggerStartDate = startDate.getTime();
                Intent startIntent = new Intent(AssessmentDetails.this, MyReceiver.class);
                startIntent.putExtra("Key", "Assessment: " + startAssessment + " starts today!");
                PendingIntent startSender = PendingIntent.getBroadcast(AssessmentDetails.this, MainActivity.numAlert++, startIntent,0);
                AlarmManager startAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                startAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerStartDate, startSender);

                /** Toast message that indicates user that alert was set.*/
                Toast.makeText(AssessmentDetails.this, "Start Date Alert Notification Set!", Toast.LENGTH_SHORT).show();

                return true;
            case R.id.endNotify:
                String endDateFromScreen = endDateTxt.getText().toString();

                /**Course Details.*/
                String endAssessment = assessmentTitle.getText().toString();

                Date endDate = null;
                try{
                    endDate = sdf.parse(endDateFromScreen);
                }catch (ParseException e){
                    e.printStackTrace();
                }
                Long triggerEndDate = endDate.getTime();
                Intent endIntent = new Intent(AssessmentDetails.this, MyReceiver.class);
                endIntent.putExtra("Key", "Assessment: " + endAssessment + " due today!");
                PendingIntent endSender = PendingIntent.getBroadcast(AssessmentDetails.this, MainActivity.numAlert++, endIntent,0);
                AlarmManager endAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                endAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerEndDate, endSender);

                /** Toast message that indicates user that alert was set.*/
                Toast.makeText(AssessmentDetails.this, "End Date Alert Notification Set!", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Method that updates an assessment.
     * @param view
     */
    public void onClickUpdateAssessment(View view) {

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(AssessmentDetails.this, UpdateAssessment.class);

        intent.putExtra("Assessment Course ID", getIntent().getIntExtra("Assessment Course ID", 0));
        intent.putExtra("Assessment ID", getIntent().getIntExtra("Assessment ID", 0));
        intent.putExtra("Assessment Course Name", getIntent().getStringExtra("Assessment Course Name"));
        intent.putExtra("Assessment Name", getIntent().getStringExtra("Assessment Name"));
        intent.putExtra("Assessment Type", getIntent().getStringExtra("Assessment Type"));
        intent.putExtra("Assessment Start Date", getIntent().getStringExtra("Assessment Start Date"));
        intent.putExtra("Assessment End Date", getIntent().getStringExtra("Assessment End Date"));

        startActivity(intent);
    }

    /**
     * Method that deletes an assessment.
     * @param view
     */
    public void onClickDeleteAssessment(View view) {

        /** Creates repository instance to access DAO methods.*/
        Repository repository = new Repository(getApplication());

        /** Assessment Object.*/
        Assessment deleteAssessment = null;

        /** Get assessment ID.*/
        int assessmentID = getIntent().getIntExtra("Assessment ID", 0);

        /** For loop that looks for the assessment to be deleted.*/
        for(Assessment a : repository.getmAllAssessments()){
            if(a.getAssessmentID() == assessmentID){
                deleteAssessment = a;
            }
        }

        /** Delete the assessment.*/
        repository.delete(deleteAssessment);
        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(AssessmentDetails.this, MainActivity.class);
        /** Starts next screen.*/
        startActivity(intent);

        /** Displays message when a new term is added.*/
        Toast.makeText(AssessmentDetails.this, "Assessment Deleted!", Toast.LENGTH_SHORT).show();

    }
}