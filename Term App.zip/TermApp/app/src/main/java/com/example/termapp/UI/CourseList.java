package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;

import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Course;
import com.example.termapp.R;

import java.util.ArrayList;
import java.util.List;

public class CourseList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_list);

        /** Java code for course list.*/

        RecyclerView recyclerView = findViewById(R.id.courseListRecyclerView);
        Repository repository = new Repository(getApplication());
        List<Course> courses = repository.getmAllCourses();
        final CourseAdapter adapter = new CourseAdapter(this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        /**Get term ID.*/
        int termID = getIntent().getIntExtra("Term ID", 0);

        /** Filter courses.*/
        ArrayList<Course> filteredCourses = new ArrayList<>();
        for(Course c : courses){
            if(c.getTermID() == termID){
                filteredCourses.add(c);
            }
        }

        /** Sends a list of filtered courses.*/
        adapter.setCourses(filteredCourses);
    }
}
