package com.example.termapp.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.termapp.Entity.Assessment;

import java.util.List;

@Dao
public interface AssessmentDAO {

    /** Inserting an assessment.*/
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Assessment assessment);

    /** Update a term.*/
    @Update
    void update(Assessment assessment);

    /** Delete a term.*/
    @Delete
    void delete(Assessment assessment);


    @Query("SELECT * FROM assessments ORDER BY assessmentID ASC")
    List<Assessment> getAllAssessments();

}
