package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Assessment;
import com.example.termapp.Entity.PerformanceAssessment;
import com.example.termapp.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class UpdateAssessment extends AppCompatActivity {

    /** GUI Fields.*/
    private EditText assessmentCourseName;
    private EditText assessmentName;
    private Spinner selectAssessmentType;
    private EditText assessmentStartDate;
    private EditText assessmentEndDate;

    /**String that stores the selected status.*/
    private PerformanceAssessment assessmentType;

    /** DatePicker */
    DatePickerDialog.OnDateSetListener startDate;
    DatePickerDialog.OnDateSetListener endDate;

    /** Calendar Object */
    final Calendar myCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_assessment);

        Repository repository = new Repository(getApplication()); // Creates repository instance

        /** Identifying GUI controls.*/
        assessmentCourseName = (EditText) findViewById(R.id.assessmentCourseEditText);
        assessmentName = (EditText) findViewById(R.id.assessmentNameEdiText);
        assessmentStartDate = (EditText) findViewById(R.id.assessmentStartDateEditText);
        assessmentEndDate = (EditText) findViewById(R.id.assessmentEndDateEditText);

        /** Select Assessment Spinner Code.*/
        selectAssessmentType = (Spinner) findViewById(R.id.selectAssessmentTypeSpinner);
        ArrayAdapter<PerformanceAssessment> statusAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, repository.assessmentTypeList);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        selectAssessmentType.setAdapter(statusAdapter);

        /** Pre-populate assessment spinner.*/
        String assessmentTypeName = getIntent().getStringExtra("Assessment Type");

        for(PerformanceAssessment p : repository.assessmentTypeList){
            if(p.getPerformanceAssessment().equals(assessmentTypeName)){
                selectAssessmentType.setSelection(p.getPerformanceAssessmentID());
            }
        }

        /** Assessment Type Spinner Code.*/
        selectAssessmentType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                assessmentType = repository.assessmentTypeList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /** Set values for the text views.*/
        assessmentCourseName.setText(getIntent().getStringExtra("Assessment Course Name"));
        assessmentName.setText(getIntent().getStringExtra("Assessment Name"));
        assessmentStartDate.setText(getIntent().getStringExtra("Assessment Start Date"));
        assessmentEndDate.setText(getIntent().getStringExtra("Assessment End Date"));


        /** Format Date */
        String dateFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);

        /** Enable EditText to pick a date .*/
        assessmentStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = assessmentStartDate.getText().toString();

                try {
                    myCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                new DatePickerDialog(UpdateAssessment.this, startDate, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        assessmentEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = assessmentEndDate.getText().toString();

                try{
                    myCalendar.setTime(sdf.parse(info));
                } catch (ParseException e){
                    e.printStackTrace();
                }

                new DatePickerDialog(UpdateAssessment.this, endDate, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartDateEditText();
            }
        };

        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateEndDateEditText();
            }
        };
    }// onCreate

    /**Methods that update the start and end date fields.*/
    private void updateStartDateEditText(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat df = new SimpleDateFormat(myFormat, Locale.US);

        assessmentStartDate.setText(df.format(myCalendar.getTime()));
    }

    private void updateEndDateEditText(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat df = new SimpleDateFormat(myFormat, Locale.US);

        assessmentEndDate.setText(df.format(myCalendar.getTime()));
    }

    public void onClickSaveAssessment(View view) {

        /**Fields to update.*/
        String updateAssessmentCourseName = assessmentCourseName.getText().toString();
        String updateAssessmentName = assessmentName.getText().toString();
        String updateAssessmentType = assessmentType.getPerformanceAssessment();
        String updateAssessmentStartDate = assessmentStartDate.getText().toString();
        String updateAssessmentEndDate = assessmentEndDate.getText().toString();

        /** Update a course by assessment by ID.*/
        int assessmentID = getIntent().getIntExtra("Assessment ID", 0);

        /** Maintain course ID.*/
        int courseID = getIntent().getIntExtra("Assessment Course ID", 0);

        /** Creates repository instance to access DAO methods.*/
        Repository repository = new Repository(getApplication());

        /** Formats Dates.*/
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        Date start = null;
        Date end = null;
        try{
            start = sdf.parse(updateAssessmentStartDate);
            end = sdf.parse(updateAssessmentEndDate);
        } catch(ParseException e){
            e.printStackTrace();
        }

        /** Create new assessment object.*/
        Assessment updatedAssessment = new Assessment(assessmentID, courseID, updateAssessmentCourseName, updateAssessmentType, updateAssessmentName, start, end );
        repository.update(updatedAssessment);

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(UpdateAssessment.this, MainActivity.class);
        /** Starts next screen.*/
        startActivity(intent);

        /** Displays message when a new term is added.*/
        Toast.makeText(UpdateAssessment.this, "Course Updated!", Toast.LENGTH_SHORT).show();

    }
}