package com.example.termapp.Entity;

import androidx.room.PrimaryKey;

public class Status {

    /** Status  Fields.*/
    @PrimaryKey(autoGenerate = true)
    private int statusID;
    private String statusName;

    public Status(int statusID, String statusName) {
        this.statusID = statusID;
        this.statusName = statusName;
    }

    /** Displays list with status names.*/
    public String toString() {
        return this.statusName;
    }

    public int getStatusID() {
        return statusID;
    }

    public void setStatusID(int statusID) {
        this.statusID = statusID;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }
}
