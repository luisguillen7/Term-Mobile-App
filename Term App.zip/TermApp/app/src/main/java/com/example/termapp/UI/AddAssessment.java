package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Assessment;
import com.example.termapp.Entity.Course;
import com.example.termapp.Entity.PerformanceAssessment;
import com.example.termapp.Entity.Term;
import com.example.termapp.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddAssessment extends AppCompatActivity {

    /** Assessment Fields.*/
    private Spinner courseSpinner;
    private Spinner assessmentTypeSpinner;
    private EditText assessmentTitleTxt;
    private EditText startDateTxt;
    private EditText endDateTxt;

    /** Creates course instance.*/
    private Course courseSelected;

    /** DatePicker */
    DatePickerDialog.OnDateSetListener startDate;
    DatePickerDialog.OnDateSetListener endDate;

    /** Calendar Object */
    final Calendar myCalendar = Calendar.getInstance();

    /** String that stores the status selected from the spinner.*/
    Course selectedCourse = null;

    /** String that stores the status selected from the spinner.*/
    PerformanceAssessment selectedAssessmentType = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_assessment);

        /** Displays spinner with courses.*/
        Repository repository = new Repository(getApplication()); // Creates repository instance
        courseSpinner = (Spinner) findViewById(R.id.selectCourseSpinner); // Creates spinner object and ties it to the spinner widget.
        ArrayAdapter<Course> courseAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, repository.getmAllCourses());
        courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        courseSpinner.setAdapter(courseAdapter);

        courseSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                /** Creates an instance of the repository in order to access the list of terms from database.*/
                Repository repository = new Repository(getApplication());

                /** The selectedTerm stores the term selected from the spinner.*/
                selectedCourse = repository.getmAllCourses().get(position);

                /** Getting the selected course.*/
                courseSelected = (Course) courseSpinner.getSelectedItem();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /** Displays spinner with status options.*/
        assessmentTypeSpinner = (Spinner) findViewById(R.id.assessmentSpinner); // Creates spinner object and ties it to the spinner widget.
        ArrayAdapter<PerformanceAssessment> assessmentAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, repository.assessmentTypeList);
        assessmentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        assessmentTypeSpinner.setAdapter(assessmentAdapter);

        /** Code that executes when an item is selected on the spinner.*/
        assessmentTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                /** The selectedAssessmentType stores the assessment type selected from the spinner.*/
                selectedAssessmentType = repository.assessmentTypeList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /** Assigning GUI identifiers.*/
        assessmentTitleTxt = (EditText) findViewById(R.id.assessmentTitleEditText);
        startDateTxt = (EditText) findViewById(R.id.startDateEditText);
        endDateTxt = (EditText) findViewById(R.id.endDateEditText);

        /** Format Date */
        String dateFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);

        /** Enable EditText to pick a date .*/
        startDateTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = startDateTxt.getText().toString();

                try {
                    myCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                new DatePickerDialog(AddAssessment.this, startDate, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        endDateTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = endDateTxt.getText().toString();

                try{
                    myCalendar.setTime(sdf.parse(info));
                } catch (ParseException e){
                    e.printStackTrace();
                }

                new DatePickerDialog(AddAssessment.this, endDate, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        /** Storing the date selected.*/
        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartDateEditText();
            }
        };

        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateEndDateEditText();
            }
        };
    } // onCreate

    /**
     * Method that updates the start date text field with a start date.
     */
    private void updateStartDateEditText(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat df = new SimpleDateFormat(myFormat, Locale.US);

        startDateTxt.setText(df.format(myCalendar.getTime()));
    }

    /**
     * Method that updates the end date text field with a end date.
     */
    private void updateEndDateEditText(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat df = new SimpleDateFormat(myFormat, Locale.US);

        endDateTxt.setText(df.format(myCalendar.getTime()));
    }

    /**
     * Method that adds a new assessment.
     * @param view
     */
    public void onClickAddAssessment(View view) {

        /** Get data from the GUI widgets.*/
        String courseSelected = selectedCourse.toString();
        String assessmentSelected = selectedAssessmentType.getPerformanceAssessment();
        String assessmentTitle = assessmentTitleTxt.getText().toString();
        String startDate = startDateTxt.getText().toString();
        String endDate = endDateTxt.getText().toString();

        /** Creates repository instance to access DAO methods.*/
        Repository repository = new Repository(getApplication());

        /** Retrieve the course ID from the selected course.*/
        int courseID = selectedCourse.getCourseID();

        /** Converts date objects into string objects.*/
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        Date start = null;
        Date end = null;
        try{
            start = sdf.parse(startDate);
            end = sdf.parse(endDate);
        } catch(ParseException e){
            e.printStackTrace();
        }

        /** Create new assessment object.*/
        Assessment newAssessment = new Assessment(0, courseID, courseSelected, assessmentSelected, assessmentTitle, start, end);

        /** Adds a new course to the assessment table in the database.*/
        repository.insert(newAssessment);

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(AddAssessment.this, MainActivity.class);
        /** Starts next screen.*/
        startActivity(intent);

        /** Displays message when a new term is added.*/
        Toast.makeText(AddAssessment.this, "Assessment Added!", Toast.LENGTH_SHORT).show();
    }
}