package com.example.termapp.DAO;

import android.provider.ContactsContract;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.termapp.Entity.Term;

import java.util.List;

@Dao
public interface TermDAO {

    /** Inserting a term.*/
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Term term);

    /** Update a term.*/
    @Update
    void update(Term term);

    /** Delete a term.*/
    @Delete
    void delete(Term term);

    /** Selects everything from the Term table.*/
    @Query("SELECT * FROM terms ORDER BY termID ASC")
    List<Term> getAllTerms();

}
