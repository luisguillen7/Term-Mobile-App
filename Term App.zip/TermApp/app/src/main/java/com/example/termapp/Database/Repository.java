package com.example.termapp.Database;

import android.app.Application;

import com.example.termapp.DAO.AssessmentDAO;
import com.example.termapp.DAO.CourseDAO;
import com.example.termapp.DAO.TermDAO;
import com.example.termapp.Entity.Assessment;
import com.example.termapp.Entity.Course;
import com.example.termapp.Entity.PerformanceAssessment;
import com.example.termapp.Entity.Status;
import com.example.termapp.Entity.Term;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {

    private TermDAO mTermDAO;
    private CourseDAO mCourseDAO;
    private AssessmentDAO mAssessmentDAO;

    /** Lists that store data objects .*/
    private List<Term> mAllTerms;
    private List<Course> mAllCourses;
    private List<Assessment> mAllAssessments;

    /** List that stores the status options.*/
    public final ArrayList<Status> statusList = new ArrayList<>();

    /** List the stores the assessment options.*/
    public final ArrayList<PerformanceAssessment> assessmentTypeList = new ArrayList<>();

    private static int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public Repository(Application application){
        TermDatabaseBuilder db = TermDatabaseBuilder.getDatabase(application);
        mTermDAO = db.termDAO();
        mCourseDAO = db.courseDAO();
        mAssessmentDAO = db.assessmentDAO();

        /** Create status objects.*/
        Status statusInProgress = new Status(0, "In Progress");
        Status statusCompleted = new Status(1, "Completed");
        Status statusPlanToTake = new Status(2, "Plan to Take");
        Status statusDropped = new Status(3, "Dropped");

        /** Populates the status list.*/
        statusList.add(statusInProgress);
        statusList.add(statusCompleted);
        statusList.add(statusPlanToTake);
        statusList.add(statusDropped);

        /** Create performance assessment objects.*/
        PerformanceAssessment performance = new PerformanceAssessment(0, "Performance");
        PerformanceAssessment objective = new PerformanceAssessment(1, "Objective");

        /** Populates the assessment list.*/
        assessmentTypeList.add(performance);
        assessmentTypeList.add(objective);
    }

    /**
     * Method that inserts a term object into the database.
     * @param term Term object
     */
    public void insert(Term term){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Inserts a term object.*/
            mTermDAO.insert(term);
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    /**
     * Method that inserts a term object into the database.
     * @param term Term object
     */
    public void update(Term term){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Inserts a term object.*/
            mTermDAO.update(term);
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    /**
     * Method that deletes a term object from the database.
     * @param term Term object
     */
    public void delete(Term term){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Inserts a term object.*/
            mTermDAO.delete(term);
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    }


    /**
     * Method that returns a list of term objects.
     * @return
     */
    public List<Term> getmAllTerms(){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Populates the AllTerms list with the terms stored in the database.*/
            mAllTerms = mTermDAO.getAllTerms();
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }

        /** Returns list of terms.*/
        return mAllTerms;
    }

    /**
     * Method that inserts a course object into the database.
     * @param course Term object
     */
    public void insert(Course course){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Inserts a term object.*/
            mCourseDAO.insert(course);
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    /**
     * Method that inserts a course object into the database.
     * @param course Course object
     */
    public void update(Course course){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Inserts a term object.*/
            mCourseDAO.update(course);
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    /**
     * Method that deletes a course object from the database.
     * @param course Term object
     */
    public void delete(Course course){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Inserts a term object.*/
            mCourseDAO.delete(course);
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    /**
     * Method that returns a list of courses objects.
     * @return
     */
    public List<Course> getmAllCourses(){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Populates the AllCourses list with the courses stored in the database.*/
            mAllCourses = mCourseDAO.getAllCourses();
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }

        /** Returns list of terms.*/
        return mAllCourses;
    }

    /**
     * Method that inserts a term object into the database.
     * @param assessment Assessment object
     */
    public void insert(Assessment assessment){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Inserts a term object.*/
            mAssessmentDAO.insert(assessment);
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    /**
     * Method that updates an assessment object into the database.
     * @param assessment Assessment object
     */
    public void update(Assessment assessment){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Inserts a term object.*/
            mAssessmentDAO.update(assessment);
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    }


    /**
     * Method that updates an assessment object into the database.
     * @param assessment Assessment object
     */
    public void delete(Assessment assessment){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Inserts a term object.*/
            mAssessmentDAO.delete(assessment);
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    /**
     * Method that returns a list of assessments objects.
     * @return
     */
    public List<Assessment> getmAllAssessments(){

        /** Executes database query.*/
        databaseExecutor.execute(()->{

            /** Populates the AllTerms list with the assessments stored in the database.*/
            mAllAssessments = mAssessmentDAO.getAllAssessments();
        });

        /** Thread gives time for the database to fetch data.*/
        try{
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }

        /** Returns list of terms.*/
        return mAllAssessments;
    }
}
