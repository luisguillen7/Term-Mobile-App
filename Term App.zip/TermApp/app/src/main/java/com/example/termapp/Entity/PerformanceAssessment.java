package com.example.termapp.Entity;

import androidx.room.PrimaryKey;

public class PerformanceAssessment {

    /** Status  Fields.*/
    @PrimaryKey(autoGenerate = true)
    private int performanceAssessmentID;
    private String performanceAssessment;

    /** Constructor.*/
    public PerformanceAssessment(int performanceAssessmentID, String performanceAssessment) {
        this.performanceAssessmentID = performanceAssessmentID;
        this.performanceAssessment = performanceAssessment;
    }

    /** To display performance name in lists.*/
    public String toString() {
        return this.performanceAssessment;
    }

    /** Getters And Setters.*/
    public int getPerformanceAssessmentID() {
        return performanceAssessmentID;
    }

    public void setPerformanceAssessmentID(int performanceAssessmentID) {
        this.performanceAssessmentID = performanceAssessmentID;
    }

    public String getPerformanceAssessment() {
        return performanceAssessment;
    }

    public void setPerformanceAssessment(String performanceAssessment) {
        this.performanceAssessment = performanceAssessment;
    }
}
