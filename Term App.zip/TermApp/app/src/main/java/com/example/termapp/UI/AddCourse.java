package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.TypeConverters;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.termapp.Database.DateConverter;
import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Course;
import com.example.termapp.Entity.Status;
import com.example.termapp.Entity.Term;
import com.example.termapp.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

@TypeConverters(DateConverter.class)
public class AddCourse extends AppCompatActivity {

    /** GUI Widgets */
    private EditText courseNameTxt;
    private EditText startDateTxt;
    private EditText endDateTxt;
    private Spinner statusSpinner;
    private Spinner termSpinner;
    private EditText instructorNameTxt;
    private EditText phoneNumberTxt;
    private EditText emailTxt;
    private EditText notesTxt;

    /** DatePicker */
    DatePickerDialog.OnDateSetListener startDate;
    DatePickerDialog.OnDateSetListener endDate;

    /** Calendar Object */
    final Calendar myCalendar = Calendar.getInstance();

    /** Create instance of a term object.*/
    Term selectedTerm = null;

    /** String that stores the status selected from the spinner.*/
    Status selectedStatus = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);

        /** Displays spinner with terms.*/
        Repository repository = new Repository(getApplication()); // Creates repository instance
        termSpinner = (Spinner) findViewById(R.id.selectTermSpinner); // Creates spinner object and ties it to the spinner widget.
        ArrayAdapter<Term> termAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, repository.getmAllTerms());
        termAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        termSpinner.setAdapter(termAdapter);

        /** Selecting an item from the term spinner.*/
        termSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                /** Creates an instance of the repository in order to access the list of terms from database.*/
                Repository repository = new Repository(getApplication());

                /** The selectedTerm stores the term selected from the spinner.*/
                selectedTerm = repository.getmAllTerms().get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /** Displays spinner with status options.*/
        statusSpinner = (Spinner) findViewById(R.id.selectStatusSpinner); // Creates spinner object and ties it to the spinner widget.
        ArrayAdapter<Status> statusAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, repository.statusList);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        statusSpinner.setAdapter(statusAdapter);

        /** Selecting an item from the status spinner.*/
        statusSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                /** The selectedTerm stores the term selected from the spinner.*/
                selectedStatus = repository.statusList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        /** Tie widgets previously declared with the XML file widgets.*/

        courseNameTxt = (EditText) findViewById(R.id.courseTitleEditText);
        startDateTxt = (EditText) findViewById(R.id.courseStartDateEditText);
        endDateTxt = (EditText) findViewById(R.id.courseEndDateEditText);
        instructorNameTxt = (EditText) findViewById(R.id.instructorNameEditText);
        phoneNumberTxt = (EditText) findViewById(R.id.instructorPhoneNumberEditText);
        emailTxt = (EditText) findViewById(R.id.instructorEmailEditText);
        notesTxt = (EditText) findViewById(R.id.notesEditText);

        /** Format Date */
        String dateFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);

        /** Enable EditText to pick a date .*/
        startDateTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = startDateTxt.getText().toString();

                try {
                    myCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                new DatePickerDialog(AddCourse.this, startDate, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        endDateTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = endDateTxt.getText().toString();

                try{
                    myCalendar.setTime(sdf.parse(info));
                } catch (ParseException e){
                    e.printStackTrace();
                }

                new DatePickerDialog(AddCourse.this, endDate, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        /** Storing the date selected.*/
        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartDateEditText();
            }
        };

        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateEndDateEditText();
            }
        };
    } // OnCreate method


    /**
     * Method that updates the start date text field with a start date.
     */
    private void updateStartDateEditText(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat df = new SimpleDateFormat(myFormat, Locale.US);

        startDateTxt.setText(df.format(myCalendar.getTime()));
    }

    /**
     * Method that updates the end date text field with a end date.
     */
    private void updateEndDateEditText(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat df = new SimpleDateFormat(myFormat, Locale.US);

        endDateTxt.setText(df.format(myCalendar.getTime()));
    }

    /**
     * Method that saves a new course to the database.
     * @param view
     */
    public void onClickSaveCourse(View view) {

        /** Get the data from the GUI widgets.*/
        String courseTitle = courseNameTxt.getText().toString();
        String startDate = startDateTxt.getText().toString();
        String endDate = endDateTxt.getText().toString();
        String instructorName = instructorNameTxt.getText().toString();
        String phoneNumber = phoneNumberTxt.getText().toString();
        String email = emailTxt.getText().toString();
        String notes = notesTxt.getText().toString();
        String termSelected = selectedTerm.toString();
        String statusSelected = selectedStatus.getStatusName();


        /** Get term ID.*/
        int termID = selectedTerm.getTermID();

        /** Creates repository instance to access DAO methods.*/
        Repository repository = new Repository(getApplication());

        /** Converts date objects into string objects.*/
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        Date start = null;
        Date end = null;
        try{
            start = sdf.parse(startDate);
            end = sdf.parse(endDate);
        } catch(ParseException e){
            e.printStackTrace();
        }

        /** Create new course object.*/
        Course newCourse = new Course(0, termID, termSelected, courseTitle, start, end, statusSelected, instructorName, phoneNumber, email, notes);

        /** Adds a new course to the course table in the database.*/
        repository.insert(newCourse);

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(AddCourse.this, MainActivity.class);
        /** Starts next screen.*/
        startActivity(intent);

        /** Displays message when a new term is added.*/
        Toast.makeText(AddCourse.this, "Course Added!", Toast.LENGTH_SHORT).show();
    }
}