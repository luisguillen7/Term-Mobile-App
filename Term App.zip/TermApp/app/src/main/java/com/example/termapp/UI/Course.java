package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Term;
import com.example.termapp.R;

import java.util.ArrayList;

public class Course extends AppCompatActivity {

    /** Creates term object.*/
    private Term selectedTerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);

        /** Displays all terms in the spinner. */
        Repository repository = new Repository(getApplication()); // Creates repository instance
        Spinner termSpinner = (Spinner) findViewById(R.id.termCourseSpinner); // Creates spinner object and ties it to the spinner widget.
        ArrayAdapter<Term> termAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, repository.getmAllTerms());
        termAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        termSpinner.setAdapter(termAdapter);

        termSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                selectedTerm = (Term) termSpinner.getSelectedItem();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    /**
     * Sends user to screen where the user can add a course.
     * @param view
     */
    public void onClickAddCourse(View view) {
        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(Course.this, AddCourse.class);
        startActivity(intent);
    }

    /** HOW TO FILTER A COURSE LIST WITH ONLY COURSES THAT BELONG TO A TERM.*/

    /**
     * Sends user to a list of courses.
     * @param view
     */
    public void onClickViewCourses(View view) {

        Repository repository = new Repository(getApplication()); // Creates repository instance
        /** List that holds the courses of a term.*/
        ArrayList<com.example.termapp.Entity.Course> coursesOfTerm = new ArrayList<>();

        /** For loop that gets the courses of a term.*/
        for(com.example.termapp.Entity.Course c : repository.getmAllCourses()){
            int termID = selectedTerm.getTermID();
            if(c.getTermID() == termID){
                coursesOfTerm.add(c);
            }
        }

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(Course.this, CourseList.class);
        intent.putExtra("Term ID", selectedTerm.getTermID());
        startActivity(intent);

    }
}