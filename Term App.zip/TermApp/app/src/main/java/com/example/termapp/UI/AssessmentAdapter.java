package com.example.termapp.UI;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.termapp.Entity.Assessment;
import com.example.termapp.R;

import java.text.SimpleDateFormat;
import java.util.List;

public class AssessmentAdapter extends RecyclerView.Adapter<AssessmentAdapter.AssessmentViewHolder> {
    class AssessmentViewHolder extends RecyclerView.ViewHolder{
        private final TextView assessmentItemView;
        private AssessmentViewHolder(View itemView){
            super(itemView);
            assessmentItemView = itemView.findViewById(R.id.assessmentNameTextView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    final Assessment current = mAssessments.get(position);

                    /** Date formatter*/
                    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

                    /** Sends information to the recycler view.*/
                    Intent intent = new Intent(context, AssessmentDetails.class);

                    intent.putExtra("Assessment ID", current.getAssessmentID());
                    intent.putExtra("Assessment Course ID", current.getCourseID());
                    intent.putExtra("Assessment Course Name", current.getAssessmentCourse());
                    intent.putExtra("Assessment Name", current.getAssessmentTitle());
                    intent.putExtra("Assessment Type", current.getAssessmentType());
                    intent.putExtra("Assessment Start Date", sdf.format(current.getStarDate()));
                    intent.putExtra("Assessment End Date", sdf.format(current.getEndDate()));

                    context.startActivity(intent);
                }
            });
        }
    }

    private List<Assessment> mAssessments;
    private final Context context;
    private final LayoutInflater mInflater;

    public AssessmentAdapter(Context context){
        mInflater = LayoutInflater.from(context);
        this.context = context;
    }

    @NonNull
    @Override
    public AssessmentAdapter.AssessmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.assessment_list_item, parent, false);
        return new AssessmentViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull AssessmentAdapter.AssessmentViewHolder holder, int position) {
        if(mAssessments != null){
            Assessment current = mAssessments.get(position);
            String name = current.getAssessmentTitle();
            holder.assessmentItemView.setText(name);
        }
        else{
            holder.assessmentItemView.setText("No assessment");
        }

    }

    public void setAssessments(List<Assessment> assessments){
        mAssessments = assessments;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if(mAssessments != null){
            return mAssessments.size();
        }
        else return 0;
    }
}
