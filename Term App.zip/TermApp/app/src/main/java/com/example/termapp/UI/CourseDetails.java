package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.TypeConverters;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.termapp.Database.DateConverter;
import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Assessment;
import com.example.termapp.Entity.Course;
import com.example.termapp.Entity.Term;
import com.example.termapp.R;

import org.w3c.dom.Text;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CourseDetails extends AppCompatActivity {

    TextView courseName;
    TextView courseStatus;
    TextView courseInstructor;
    TextView coursePhoneNumber;
    TextView courseEmail;
    TextView courseStartDate;
    TextView courseEndDate;
    TextView courseNotes;

    String myFormat = "MM/dd/yy";
    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);

        /** Displays the action bar.*/
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        /** Identifying GUI controls.*/
        courseName = (TextView) findViewById(R.id.courseNameTextView);
        courseStatus = (TextView) findViewById(R.id.courseStatusTextView);
        courseInstructor = (TextView) findViewById(R.id.courseInstructorTextView);
        coursePhoneNumber = (TextView) findViewById(R.id.courseInstructorPhoneNumberTextView);
        courseEmail = (TextView) findViewById(R.id.courseInstructorEmailTextView);
        courseStartDate = (TextView) findViewById(R.id.courseStartDateTextView);
        courseEndDate = (TextView) findViewById(R.id.courseEndDateTextView);
        courseNotes = (TextView) findViewById(R.id.courseNotesTextView);

        /** Set values for the text views.*/
        courseName.setText(getIntent().getStringExtra("Course Name"));
        courseStatus.setText(getIntent().getStringExtra("Status"));
        courseStartDate.setText(getIntent().getStringExtra("Start Date"));
        courseEndDate.setText(getIntent().getStringExtra("End Date"));
        courseInstructor.setText(getIntent().getStringExtra("Instructor Name"));
        coursePhoneNumber.setText(getIntent().getStringExtra("Phone Number"));
        courseEmail.setText(getIntent().getStringExtra("Email"));
        courseNotes.setText(getIntent().getStringExtra("Notes"));

    }

    public void onClickUpdateCourse(View view) {

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(CourseDetails.this, UpdateCourse.class);

        intent.putExtra("Course ID", getIntent().getIntExtra("Course ID", 0));
        intent.putExtra("Term ID", getIntent().getIntExtra("Term ID", 0));
        intent.putExtra("Term", getIntent().getStringExtra("Term"));
        intent.putExtra("Course Name", getIntent().getStringExtra("Course Name"));
        intent.putExtra("Status", getIntent().getStringExtra("Status"));
        intent.putExtra("Start Date", getIntent().getStringExtra("Start Date"));
        intent.putExtra("End Date", getIntent().getStringExtra("End Date"));
        intent.putExtra("Instructor Name", getIntent().getStringExtra("Instructor Name"));
        intent.putExtra("Phone Number", getIntent().getStringExtra("Phone Number"));
        intent.putExtra("Email", getIntent().getStringExtra("Email"));
        intent.putExtra("Notes", getIntent().getStringExtra("Notes"));

        /** Starts new activity.*/
        startActivity(intent);

    }

    /** ACTION BAR CODE.*/

    /** Sharing Notes Code.*/
    public boolean onCreateOptionsMenu(Menu menu){

        /** Inflate the menu, This adds items to the action bar if it is present.*/
        getMenuInflater().inflate(R.menu.course_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case android.R.id.home:this.finish();
            return true;
            case R.id.share:
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, courseNotes.getText());
                sendIntent.putExtra(Intent.EXTRA_TITLE, "Message Title");
                sendIntent.setType("text/plain");
                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
                return true;
            case R.id.startNotify:
                String startDateFromScreen = courseStartDate.getText().toString();

                /**Course Details.*/
                String startCourse = courseName.getText().toString();

                Date startDate = null;
                try{
                    startDate = sdf.parse(startDateFromScreen);
                }catch (ParseException e){
                    e.printStackTrace();
                }
                Long triggerCourseStartDate = startDate.getTime();
                Intent startIntent = new Intent(CourseDetails.this, MyReceiver.class);
                startIntent.putExtra("Key", "Course: " + startCourse + " starts today!");
                PendingIntent startCourseSender = PendingIntent.getBroadcast(CourseDetails.this,MainActivity.numAlert++, startIntent,0);
                AlarmManager startAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                startAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerCourseStartDate, startCourseSender);

                /** Toast message that indicates user that alert was set.*/
                Toast.makeText(CourseDetails.this, "Start Date Alert Notification Set!", Toast.LENGTH_SHORT).show();

                return true;
            case R.id.endNotify:
                String endDateFromScreen = courseEndDate.getText().toString();

                /**Course Details.*/
                String endCourse = courseName.getText().toString();

                Date endDate = null;
                try{
                    endDate = sdf.parse(endDateFromScreen);
                }catch (ParseException e){
                    e.printStackTrace();
                }
                Long triggerCourseEndDate = endDate.getTime();
                Intent endIntent = new Intent(CourseDetails.this, MyReceiver.class);
                endIntent.putExtra("Key", "Course: " + endCourse + " ends today!");
                PendingIntent endCourseSender = PendingIntent.getBroadcast(CourseDetails.this, MainActivity.numAlert++, endIntent,0);
                AlarmManager endAlarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                endAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerCourseEndDate, endCourseSender);

                /** Toast message that indicates user that alert was set.*/
                Toast.makeText(CourseDetails.this, "End Date Alert Notification Set!", Toast.LENGTH_SHORT).show();

        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Method that deletes a course.
     * @param view
     */
    public void onClickDeleteCourse(View view) {

        /** Creates repository instance to access DAO methods.*/
        Repository repository = new Repository(getApplication());

        /** Course Object.*/
        Course deleteCourse = null;

        /** Get course ID.*/
        int courseID = getIntent().getIntExtra("Course ID", 0);

        /** For loop that sets the term to be deleted.*/
        for(com.example.termapp.Entity.Course c : repository.getmAllCourses()){
            if(c.getCourseID() == courseID){

                /** Assign a value to the term to be deleted.*/
                deleteCourse = c;
            }
        }

        /** Number of courses.*/
        int numberOfAssessments = 0;
        for(Assessment a :  repository.getmAllAssessments()){
            if(a.getCourseID() == courseID) ++numberOfAssessments;
        }

        /** Checks if the term has course.*/
        if(numberOfAssessments == 0){

            /** Deletes course from database.*/
            repository.delete(deleteCourse);

            /** Create intent to go to the next screen.*/
            Intent intent = new Intent(CourseDetails.this, MainActivity.class);
            /** Starts next screen.*/
            startActivity(intent);

            /** Displays message when a new term is added.*/
            Toast.makeText(CourseDetails.this, "Course Deleted!", Toast.LENGTH_SHORT).show();
        } else {

            /** Displays message when a new term is added.*/
            Toast.makeText(CourseDetails.this, "Course has assessments and cannot be deleted.", Toast.LENGTH_SHORT).show();
        }

    }
}