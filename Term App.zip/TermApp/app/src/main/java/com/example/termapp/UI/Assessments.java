package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Assessment;
import com.example.termapp.Entity.Course;
import com.example.termapp.Entity.Term;
import com.example.termapp.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class Assessments extends AppCompatActivity {

    /** Assessment fields.*/
    private Spinner termSpinner;
    private Spinner courseSpinner;

    /** Variable that stores the selected term.*/
    Term selectedTerm;

    /** Variable that stores the selected term.*/
    Course selectedCourse;

    /** Variable that stores the selected term.*/
    Assessment selectedAssessment;

    /** List that holds the courses of a term.*/
    ArrayList<Course> coursesOfTerm = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessments);

        /** Displays spinner with terms.*/
        Repository repository = new Repository(getApplication()); // Creates repository instance
        termSpinner = (Spinner) findViewById(R.id.termAssessmentSpinner); // Creates spinner object and ties it to the spinner widget.
        ArrayAdapter<Term> termAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, repository.getmAllTerms());
        termAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        termSpinner.setAdapter(termAdapter);

        /** Term Spinner onSelect.*/
        termSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                /** Creates an instance of the repository in order to access the list of terms from database.*/
                Repository repository = new Repository(getApplication());

                /** The selectedTerm stores the term selected from the spinner.*/
                selectedTerm = repository.getmAllTerms().get(position);

                /** Filter course spinner.*/
                coursesOfTerm.clear();
                for(Course c : repository.getmAllCourses()){
                    int termID = selectedTerm.getTermID();
                    if(c.getTermID() == termID) {
                        coursesOfTerm.add(c);

                        /** Populates the course spinner with courses that belong to a term.*/
                        courseSpinner = (Spinner) findViewById(R.id.courseAssessmentSpinner); // Creates spinner object and ties it to the spinner widget.
                        ArrayAdapter<Course> courseAdapter = new ArrayAdapter<Course>(Assessments.this, android.R.layout.simple_spinner_item, coursesOfTerm);
                        courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
                        courseSpinner.setAdapter(courseAdapter);
                    }
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        /*
        selectedTerm = (Term) termSpinner.getSelectedItem();
        coursesOfTerm.clear();
        for(Course c : repository.getmAllCourses()){
            int termID = selectedTerm.getTermID();
            if(c.getTermID() == termID){
                coursesOfTerm.add(c);
            }
        }

         */

        /** Displays spinner with courses.*/
        courseSpinner = (Spinner) findViewById(R.id.courseAssessmentSpinner); // Creates spinner object and ties it to the spinner widget.
        ArrayAdapter<Course> courseAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, coursesOfTerm);
        courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        courseSpinner.setAdapter(courseAdapter);

        courseSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                /** The selectedTerm stores the term selected from the spinner.*/
                selectedCourse = (Course) courseSpinner.getSelectedItem();

                courseSpinner.setSelection(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void onClickViewAssessments(View view) {

        Repository repository = new Repository(getApplication()); // Creates repository instance

        /** List that holds the assessments of a course.*/
        ArrayList<Assessment> assessmentsOfCourse = new ArrayList<>();

        /** For loop that gets that assessments related to a course.*/
        for(Assessment a :repository.getmAllAssessments()){
            int courseID = selectedCourse.getCourseID();
            if(a.getCourseID() == courseID){
                assessmentsOfCourse.add(a);
            }
        }


        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(Assessments.this, AssessmentList.class);
        intent.putExtra("Assessment Course ID", selectedCourse.getCourseID());
        /** Starts the next screen.*/
        startActivity(intent);
    }


    public void onClickAddAssessment(View view) {

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(Assessments.this, AddAssessment.class);
        startActivity(intent);

    }

}