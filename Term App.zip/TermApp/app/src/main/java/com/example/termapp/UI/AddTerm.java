package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.TypeConverters;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;


import com.example.termapp.Database.DateConverter;
import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Term;
import com.example.termapp.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

@TypeConverters(DateConverter.class)
public class AddTerm extends AppCompatActivity {

    /** GUI Widgets */
    private EditText termNameTxt;
    private EditText startDateTxt;
    private EditText endDateTxt;

    /** DatePicker */
    DatePickerDialog.OnDateSetListener startDate;
    DatePickerDialog.OnDateSetListener endDate;

    /** Calendar Object */
    final Calendar myCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_term);

        /** Tie data with the previous declare GUI widgets .*/
        termNameTxt = (EditText) findViewById(R.id.termNameEditText);
        startDateTxt = (EditText) findViewById(R.id.termStartDateEditText);
        endDateTxt = (EditText) findViewById(R.id.termEndDateEditText);

        /** Format Date */
        String dateFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);

        /** Enable EditText to pick a date .*/

        startDateTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = startDateTxt.getText().toString();

                try {
                    myCalendar.setTime(sdf.parse(info));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                new DatePickerDialog(AddTerm.this, startDate, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        endDateTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date date;
                String info = endDateTxt.getText().toString();

                try{
                    myCalendar.setTime(sdf.parse(info));
                } catch (ParseException e){
                    e.printStackTrace();
                }

                new DatePickerDialog(AddTerm.this, endDate, myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        startDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                 myCalendar.set(Calendar.YEAR, year);
                 myCalendar.set(Calendar.MONTH, month);
                 myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateStartDateEditText();
            }
        };

        endDate = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateEndDateEditText();
            }
        };
    } // onCreate Method

    private void updateStartDateEditText(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat df = new SimpleDateFormat(myFormat, Locale.US);

        startDateTxt.setText(df.format(myCalendar.getTime()));
    }

    private void updateEndDateEditText(){
        String myFormat = "MM/dd/yy";
        SimpleDateFormat df = new SimpleDateFormat(myFormat, Locale.US);

        endDateTxt.setText(df.format(myCalendar.getTime()));
    }

    public void onClickSaveTerm(View view) {

        /** Get the data from the GUI widgets.*/
        String termName = termNameTxt.getText().toString();
        String startDate = startDateTxt.getText().toString();
        String endDate = endDateTxt.getText().toString();

        /** Creates repository instance to access DAO methods.*/
        Repository repository = new Repository(getApplication());

        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        Date start = null;
        Date end = null;
        try{
            start = sdf.parse(startDate);
            end = sdf.parse(endDate);
        } catch(ParseException e){
            e.printStackTrace();
        }

        /** Create new term object.*/
        Term newTerm = new Term(0, termName, start, end);

        /** Add new term object to list.*/
        repository.insert(newTerm);

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(AddTerm.this, MainActivity.class);
        /** Starts next screen.*/
        startActivity(intent);

        /** Displays message when a new term is added.*/
        Toast.makeText(AddTerm.this, "Term Added!", Toast.LENGTH_SHORT).show();
    }
} // Class