package com.example.termapp.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.example.termapp.DAO.TermDAO;
import com.example.termapp.Database.Repository;
import com.example.termapp.Entity.Course;
import com.example.termapp.Entity.Term;
import com.example.termapp.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TermList extends AppCompatActivity {

    /** Create term instance.*/
    Term selectedTerm = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_list);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        RecyclerView recyclerView = findViewById(R.id.termListRecyclerView);
        Repository repository = new Repository(getApplication());
        List<Term> terms = repository.getmAllTerms();
        final TermAdapter adapter = new TermAdapter(this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter.setmTerms(terms);



   // @Override
    /**
     * Updates data when an activity is restarted.
     */

    /*
    protected void onResume() {

        super.onResume();

        Spinner termSpinner = (Spinner) findViewById(R.id.termSpinner); // Creates spinner object and ties it to the spinner widget.
        Repository repository = new Repository(getApplication()); // Creates repository instance
        ArrayAdapter<Term> termAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, repository.getmAllTerms());
        termAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        termSpinner.setAdapter(termAdapter);

        /** Code that executes when an item is selected from that spinner.
        termSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                /** Creates an instance of the repository in order to access the list of terms from database.
                Repository repository = new Repository(getApplication());

                /** The selectedTerm stores the term selected from the spinner.
                selectedTerm = repository.getmAllTerms().get(position);
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

     */

    }

    /**
     * This is the Add Term onClick handler.
     * Sends the user to the screen where the user can add a term.
     * @param view Not used.
     */
    public void onClickAddTerm(View view) {

        /** Create intent to go to the next screen.*/
        Intent intent = new Intent(TermList.this, AddTerm.class);
        startActivity(intent);
    }

} // Class